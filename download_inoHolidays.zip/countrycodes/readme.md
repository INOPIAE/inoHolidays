Do not forget to update the holiday regional definition on the add-in configuartion sheet.

Holidays related to Easter fill in: Ostern +/- number of days

Holdidays related to last 4th Advent Sunday fill in: Advent +/- number of days

Holidays for a given day in month fill in: Tag, Month, Weekday (1- Sunday to 7 - Saturday), number of occurance (1-5, 6 last of month)

Islamic holdiays : Isl, day. month, eg. 30. Ramadan, spelling of month see [README.MD](../README.MD)
